use std::cmp::Ordering;
use std::fmt::Debug;
use std::collections::vec_deque::VecDeque;

use super::error::OpError;

pub type HeapNode<T> = Option<Box<Node<T>>>;

#[derive(Debug)]
pub struct Node<T: Ord> {
    value: T,
    left: HeapNode<T>,
    right: HeapNode<T>,
}

impl<T: Ord> Node<T> {
    pub fn new(value: T) -> Node<T> {
        return Node {
            value,
            left: None,
            right: None,
        }
    }

    pub fn search(mut root: &HeapNode<T>, value: &T) -> bool {
        while let Some(current) = root {
            match value.cmp(&current.value) {
                Ordering::Less => root = &current.left,
                Ordering::Greater => root = &current.right,

                Ordering::Equal => return true,
            }
        }

        return false;
    }

    pub fn insert(mut root: &mut HeapNode<T>, value: T) -> Result<(), OpError> {
        while let Some(ref mut n) = root {
            match value.cmp(&n.value) {
                Ordering::Less => root = &mut n.left,
                Ordering::Greater => root = &mut n.right,

                Ordering::Equal => return Err(OpError::ValueAlreadyExists),
            }
        }

        *root = Some(Box::new(Node::new(value)));
        Ok(())
    }

    pub fn get_height(root: &HeapNode<T>) -> isize {
        let mut height = -1;
        let mut queue = VecDeque::new();

        queue.push_front(root);
        while !queue.is_empty() {
            let mut size = queue.len();

            while size > 0 {
                let current = queue.pop_front().as_ref().unwrap().as_ref().unwrap();

                if current.left.is_some() {
                    queue.push_back(&current.left);
                }

                if current.right.is_some() {
                    queue.push_back(&current.right)
                }

                size -= 1;
            }

            height += 1;
        }

        return height;
    }

    pub fn get_max(mut root: &HeapNode<T>) -> Option<&T> {
        while let Some(current) = root {
            if current.right.is_none() {
                return Some(&current.value);
            }

            root = &current.right;
        }

        return None;
    }

    pub fn get_min(mut root: &HeapNode<T>) -> Option<&T> {
        while let Some(current) = root {
            if current.left.is_none() {
                return Some(&current.value);
            }

            root = &current.left;
        }

        return None;
    }

    pub fn delete_max(mut root: &mut HeapNode<T>) -> Option<T> {
        if root.is_some() {
            while root.as_ref().unwrap().right.is_some() {
                root = &mut root.as_mut().unwrap().right
            }

            let node = root.take().unwrap();
            *root = node.left;

            return Some(node.value);
        }

        return None;
    }

    pub fn delete_min(mut root: &mut HeapNode<T>) -> Option<T> {
        if root.is_some() {
            while root.as_ref().unwrap().left.is_some() {
                root = &mut root.as_mut().unwrap().left
            }

            let node = root.take().unwrap();
            *root = node.right;

            return Some(node.value);
        }

        return None;
    }

    pub fn delete(mut root: &mut HeapNode<T>, value: &T) -> Result<(), OpError> {
        while let Some(ref mut current) = root {
            match value.cmp(&current.value) {
                Ordering::Less => root = &mut root.as_mut().unwrap().left,
                Ordering::Greater => root = &mut root.as_mut().unwrap().right,

                Ordering::Equal => {
                    match (current.left.as_mut(), current.right.as_mut()) {
                        (None, None) => *root = None,
                        (Some(_), None) => *root = current.left.take(),
                        (None, Some(_)) => *root = current.right.take(),

                        (Some(_), Some(_)) => {
                            root.as_mut().unwrap().value = Node::delete_min(&mut current.right).unwrap();
                        }
                    }

                    return Ok(());
                }
            }
        }

        return Err(OpError::Unknown);
    }
}