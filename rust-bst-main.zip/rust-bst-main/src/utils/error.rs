use std::fmt::Debug;

#[derive(Debug)]
pub enum OpError {
    NoValue, 
    ValueAlreadyExists,
    NoneTree,
    NoParents,
    NoChild,
    Unknown,
}