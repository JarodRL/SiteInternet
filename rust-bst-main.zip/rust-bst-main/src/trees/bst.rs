use crate::utils::node::{
    HeapNode,
    Node,
};
use super::tree::Tree;

use std::fmt::Debug;

#[derive(Debug)]
pub struct BinarySearchTree<T: Ord> {
    root: HeapNode<T>,
    size: usize,
}

impl<T: Ord> BinarySearchTree<T> {
    pub fn new() -> BinarySearchTree<T> {
        return Self {
            root: None,
            size: 0,
        }
    }
}

impl<T: Ord> Tree<T> for BinarySearchTree<T> {
    fn get_size(&self) -> usize {
        return self.size;
    }

    fn is_empty(&self) -> bool {
        return if self.get_size() == 0 {
            true
        } else {
            false
        }
    }

    fn search(&self, value: &T) -> bool {
        return Node::search(&self.root, value);
    }

    fn insert(&mut self, value: T) {
        if Node::insert(&mut self.root, value).is_ok() {
            self.size += 1;
        }
    }

    fn get_height(&self) -> Option<isize> {
        return self.root.as_ref().map(|_| Node::get_height(&self.root));
    }

    fn get_max(&self) -> Option<&T> {
        return Node::get_max(&self.root);
    }

    fn get_min(&self) -> Option<&T> {
        return Node::get_min(&self.root);
    }

    fn delete_max(&mut self) -> Option<T> {
        let removed = Node::delete_max(&mut self.root);
        if removed.is_some() {
            self.size -= 1;
        }

        return removed;
    }

    fn delete_min(&mut self) -> Option<T> {
        let removed = Node::delete_min(&mut self.root);
        if removed.is_some() {
            self.size -= 1;
        }

        return removed;
    }

    fn delete(&mut self, value: &T) {
        if Node::delete(&mut self.root, value).is_ok() {
            self.size -= 1;
        }
    }
}