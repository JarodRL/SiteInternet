pub trait Tree<T: Ord> {
    /// Return the number of nodes.
    fn get_size(&self) -> usize;

    /// Return true if the tree contains 0 nodes.
    fn is_empty(&self) -> bool;

    /// Return true if the tree contains the given value.
    fn search(&self, value: &T) -> bool;

    /// Insert the given value as a node in the tree.
    fn insert(&mut self, value: T);

    /// Return the height of the tree or None if it's empty.
    /// The height is the number of node between the root and the furthest leaf node.
    fn get_height(&self) -> Option<isize>;

    /// Return the maximum value of the tree or None if it's empty.
    fn get_max(&self) -> Option<&T>;

    /// Return the minimum value of the tree or None if it's empty.
    fn get_min(&self) -> Option<&T>;

    /// Delete and return the minimum value of the tree or None if it's empty.
    fn delete_max(&mut self) -> Option<T>;
    
    /// Delete and return the maximum value of the tree or None if it's empty.
    fn delete_min(&mut self) -> Option<T>;

    /// Delete the given value.
    fn delete(&mut self, value: &T);
}