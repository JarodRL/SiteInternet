# rust-bst
[![license](https://img.shields.io/github/license/Mitsuaaki/rust-bst)](https://github.com/Mitsuaaki/rust-bst/blob/main/LICENSE)

> Iterative Binary Search Tree and many others written in Rust

## Table of Contents

- [Quick Start](#Quick-Start)
-  [Todo](#Todo)
- [License](#License)

## Quick Start

 ```rust
use rust_bst::trees::{
    bst::BinarySearchTree,
    tree::Tree,
};
 
fn main() {
    let mut bst = BinarySearchTree::new();
    bst.insert(5);
    bst.insert(10);
    bst.insert(-9);
    assert_eq!(bst.get_height(), 3);
}
 ```

## Todo

- [ ] Add AVL Tree
- [ ] Add RedBlack Tree
-  [ ] Add Splay Tree
-  [ ] Add Spacegoat Tree
-  [ ] Add a visualization system (graph folder)
-  [ ] Add more test and github actions etccc

## License

[MIT License](https://github.com/Mitsuaaki/rust-bst/blob/main/LICENSE)
