extern crate rust_bst;

#[cfg(test)]
mod test {
    use super::*;
    use rust_bst::trees::{
        bst::BinarySearchTree,
        tree::Tree,
    };

    #[test]
    fn insert_tree() {
        let mut bst = BinarySearchTree::new();
        bst.insert(5);
        bst.insert(-10);
        bst.insert(80);
        bst.insert(23);

        assert_eq!(bst.get_size(), 4);
    }
}